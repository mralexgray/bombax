#import <Cocoa/Cocoa.h>

@class BxSession;
@class BxTransport;

@protocol BxClientLibAuthenticator

- (BOOL)authenticateBxClientLibRequest:(BxTransport *)transport
                               session:(BxSession *)session;

@end
